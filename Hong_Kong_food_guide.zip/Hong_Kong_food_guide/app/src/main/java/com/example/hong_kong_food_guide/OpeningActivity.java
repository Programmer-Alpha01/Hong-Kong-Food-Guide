package com.example.hong_kong_food_guide;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class OpeningActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opening);
    }

    public void goto_chinese(View view) {
        startActivity(new Intent(OpeningActivity.this,english_camera.class));
    }

    public void goto_english(View view) {
        startActivity(new Intent(OpeningActivity.this,english_camera.class));
    }

    public void goto_japanese(View view) {
        startActivity(new Intent(OpeningActivity.this,english_camera.class));
    }

    public void goto_korean(View view) {
        startActivity(new Intent(OpeningActivity.this,english_camera.class));
    }
}
