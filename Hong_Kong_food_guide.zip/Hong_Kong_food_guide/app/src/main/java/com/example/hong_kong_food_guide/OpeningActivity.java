package com.example.hong_kong_food_guide;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class OpeningActivity extends Activity {
    MediaPlayer myMus = null; // a field of MediaPlayer
    @Override
    protected void onResume(){ // callback method, when interacting with user
        super.onResume(); // always call superclass
        myMus.start(); // start playing
    }
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opening);
        myMus = MediaPlayer.create(this, R.raw.backgroud_music);//sound file “bs” in raw folder
        myMus.setLooping(true);
    }

    public void goto_chinese(View view) {
        startActivity(new Intent(OpeningActivity.this,chinese_camera.class));
    }

    public void goto_english(View view) {
        startActivity(new Intent(OpeningActivity.this,english_camera.class));
    }

    public void goto_japanese(View view) {
        startActivity(new Intent(OpeningActivity.this,japanese_camera.class));
    }

    public void goto_korean(View view) {
        startActivity(new Intent(OpeningActivity.this,korean_camera.class));
    }

    public void goto_deutsch(View view) {
        startActivity(new Intent(OpeningActivity.this,deutsch_camera.class));
    }

    public void goto_portugues(View view) {
        startActivity(new Intent(OpeningActivity.this,portugues_camera.class));
    }

    public void goto_francais(View view) {
        startActivity(new Intent(OpeningActivity.this,francais_camera.class));
    }

    public void about_me(View view) {
        startActivity(new Intent(OpeningActivity.this,about_me_information.class));
    }

    public void know_more(View view) {
        startActivity(new Intent(OpeningActivity.this,know_more_information.class));
    }
}
